<template>
    <Activities title="Project Overeview" />
</template>

<script>
import Activities from './Activities.vue'
export default {
    name: 'Overview',
    components: {
        Activities
    }
}
</script>